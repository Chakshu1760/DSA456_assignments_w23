class Graph:
	
	# Class to represent vertex
    class Vertex:
        def __init__(self, name = None, weight = None):
            self.name = name
            self.weight = weight
    
    def __init__(self,number_of_verts):
        self.verts = [ [] for i in range(number_of_verts) ] # Create list for each vertex 
        self.n_verts = number_of_verts # Number of vertexes
        self.n_edges = 0 # Number of edges
    
    #Add a new additional vertex to the graph
    def add_vertex(self):
        if self in self.verts:
            print("Vertex already exists in graph")
        else:
            self.n_verts = self.n_verts + 1
            self.verts.append([])
 
    # Add edge between two nodes
    def add_edge(self,from_idx, to_idx, weight = 1 ):
        if 0 <= from_idx <= (self.num_verts()-1) and 0 <= to_idx <= (self.num_verts()-1) and not self.has_edge(from_idx,to_idx): # Check if nodes exists and they are not connected
            self.verts[from_idx].append(self.Vertex(to_idx,weight)) # Append dictionary of vertex from from_idx
            self.n_edges += 1 # Increment number of edges
            return True
        
        return False

     #return number of edges in the graph       
    def num_edges(self):
        return self.n_edges
    
    # Return number of vertexes in the graph
    def num_verts(self):
        return self.n_verts
		
	# Check if node has an edge to another node
    def has_edge(self, from_idx,to_idx):
        if 0 <= from_idx <= (self.num_verts()-1) and 0 <= to_idx <= (self.num_verts()-1) and self.verts[from_idx]: # Check if nodes exists
            
            for i in range(len(self.verts[from_idx])): #Iter connected nodes from from_idx
                if self.verts[from_idx][i].name == to_idx:
                    return True
        
        return False
    
    #returns the edge weight between two vertices
    def edge_weight(self, from_idx,to_idx):
        if not self.has_edge(from_idx,to_idx): # Check if edge exists
            return None
        
        for i in range(len(self.verts[from_idx])):  # Iter edges of from_idx
            if self.verts[from_idx][i].name == to_idx:  # Check if to_idx is connected
                return self.verts[from_idx][i].weight
        
        return None
    
    #Finding all vertices connected from v
    def get_connected(self, v):
        connections = []
        
        if 0 <= v <= (self.num_verts()-1) and self.verts[v]:    # Check if vertex is valid and it isn't empty
            for i in range(len(self.verts[v])):
                connections.append((self.verts[v][i].name,self.verts[v][i].weight))
        
        return connections