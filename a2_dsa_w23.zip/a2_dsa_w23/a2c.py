
# if you wish to use your sorted list from a1, copy and paste it here
# this is not the best way to do this but the test scripts are not
# designed to pick up an extra file. 

# Return hashIndex of value based on capacity of container
def __hashIndex__(value, capacity):
	return hash(value) % capacity

class LinearProbingTS:
	
	# This is a single record in a chaining hash table.  You can
	# change this in anyway you wish (including not using it at all)
	class Record:
		def __init__(self, key = None, value=None):
			self.key = key
			self.value = value
	
	# You cannot change the function prototypes below.  Other than that
	# how you implement the class is your choice (but it must be a hash
	# table that use chaining for collision resolution)
	
	# Default constructor
	def __init__(self, cap=32):
		self.hashTable = [{'record':None,'stone':'E'} for i in range(cap)] # Create list of dictionaries where record store Record object and stone stores Tombstone status (E = empty, X = deleted, O = occupied)
		self.nRecords = 0 # Number of records in the table
		self.cap = cap # Capacity of hashtable
	
	# Insert new key-value pair
	def insert(self, key, value):
		
		# Search if key already in hashtable
		if self.search(key):
			return False
		
		# Check load factor more than 0.7
		if (len(self)+1)/self.capacity() > 0.7:
			newHash = LinearProbingTS(self.capacity() * 2)  # New hashtabele with double capacity
			
			pos = 0 # Set position at the beginning of hashtable
			nRecords_counter = len(self)
			
			# Insert old elements in new array
			while nRecords_counter != 0:
				if self.hashTable[pos]['stone'] != 'E':
					newHash.insert(self.hashTable[pos]['record'].key,self.hashTable[pos]['record'].value)
					nRecords_counter -= 1
					
				pos += 1
			
			self.hashTable = newHash.hashTable # Save new hashtable as my hashtable
			self.cap = newHash.capacity() # Update capacity
		
		# Retrieve hashindex for key_value pair
		h_idx = __hashIndex__(key,self.capacity())
		
		# Find a spot to put record
		while self.hashTable[h_idx]['stone'] == 'O':
			h_idx = (h_idx + 1) % self.capacity() # Increment hash index to next position (circular)
		
		self.hashTable[h_idx]['stone'] = 'O' # Set position in the hashtable as occupied
		self.hashTable[h_idx]['record'] = self.Record(key,value) # Save record in the hashtable
		self.nRecords += 1 # Increment number of records
		
		return True
	
	
	# Modify value in hashtable
	def modify(self, key, value):
		# calculate the index of the key
		h_idx = __hashIndex__(key,self.capacity())
		
		# use linear probing to find the next slot
		while self.hashTable[h_idx]['stone'] != 'E':
			
			# modify the value and return True if we found the key
			if self.hashTable[h_idx]['record'] and self.hashTable[h_idx]['record'].key == key:
				self.hashTable[h_idx]['record'].value = value
				return True
			
			h_idx = (h_idx + 1) % self.capacity()
		
		# if key not found, return False
		return False
	
	
	# Remove value from hashtable
	def remove(self, key):
		# calculate the index for the  key
		h_idx = __hashIndex__(key,self.capacity())
		
		while self.hashTable[h_idx]['stone'] != 'E':
			if self.hashTable[h_idx]['record'] and self.hashTable[h_idx]['record'].key == key:
				self.hashTable[h_idx]['record'] = None
				self.hashTable[h_idx]['stone'] = 'X'
				self.nRecords -= 1
				return True
			
			# move to the next index 
			h_idx = (h_idx + 1) % self.capacity()
		
		# if the key was not found, return False
		return False
	
	# Search for node and return value
	def search(self, key):
		
		h_idx = __hashIndex__(key,self.capacity()) # Save hashIndex
		
		# Iterate until item is empty
		while self.hashTable[h_idx]['stone'] != 'E':
			
			# Check if element is found
			if self.hashTable[h_idx]['record'] and self.hashTable[h_idx]['record'].key == key:
				return self.hashTable[h_idx]['record'].value
			
			h_idx = (h_idx + 1)%self.capacity() # Increment index
		
		return None
	
	# Return capacity of hashtable
	def capacity(self):
		return self.cap
	
	# Return number of records in hashtable
	def __len__(self):
		return self.nRecords


class LinearProbingNoTS:
	
	# This is a single record in a chaining hash table.  You can
	# change this in anyway you wish (including not using it at all)
	class Record:
		def __init__(self, key = None, value=None):
			self.key = key
			self.value = value
	
	# You cannot change the function prototypes below.  Other than that
	# how you implement the class is your choice (but it must be a hash
	# table that use linear probing for collision resolution)
	
	# Default constructor
	def __init__(self, cap=32):
		self.hashTable = [None for i in range(cap)] # Create list of None values
		self.nRecords = 0 # Number of records in the table
		self.cap = cap # Capacity of Array
	
	# Insert record in hashtable
	def insert(self, key, value):

		# Search if key already in hashtable
		if self.search(key):
			return False
		
		# Check load factor more than 0.7
		if (len(self)+1)/self.capacity() > 0.7:
			newHash = LinearProbingNoTS(self.capacity() * 2)  # New hashtabele with double capacity
			
			pos = 0 # Set position at the beginning of hashtable
			nRecords_counter = len(self)
			
			# Insert old elements in new array
			while nRecords_counter != 0:
				if self.hashTable[pos]:
					newHash.insert(self.hashTable[pos].key,self.hashTable[pos].value)
					nRecords_counter -= 1
					
				pos += 1				
			
			self.hashTable = newHash.hashTable # Save new hashtable as my hashtable
			self.cap = newHash.capacity() # Update capacity
		
		# Retrieve hashindex for key_value pair
		h_idx = __hashIndex__(key,self.capacity())
		
		# Find a spot to put record
		while self.hashTable[h_idx]:
			h_idx = (h_idx + 1) % self.capacity() # Increment hash index to next position (circular)
		
		self.hashTable[h_idx]= self.Record(key,value) # Save record in the hashtable
		self.nRecords += 1 # Increment number of records
		
		return True
	
	# Modify record in hashtable
	def modify(self, key, value):
		idx = hash(key) % self.capacity()
		
		while self.hashTable[idx] is not None:
			if self.hashTable[idx].key == key:
				self.hashTable[idx].value = value
				return True
			
			idx = (idx + 1) % self.capacity()
		
		return False
	
	# Remove key-value pair if exists
	def remove(self, key):
		curr_idx = __hashIndex__(key,self.capacity()) # Save current index
		empty_idx = 0 # Save empty index
		
		# Iterate until current point to Null value
		while(self.hashTable[curr_idx]):
			
			# Check if element matches
			if(self.hashTable[curr_idx].key == key):
				
				self.hashTable[curr_idx] = None # Delete record
				empty_idx = curr_idx # Set empty position
				curr_idx = (curr_idx + 1)%self.capacity() # Increment current
				
				# Iter until end of cluster
				while(self.hashTable[curr_idx]):
					
					# Check if record at current should be shifted
					if __hashIndex__(self.hashTable[curr_idx].key,self.capacity()) <= empty_idx and empty_idx <= curr_idx:
						self.hashTable[empty_idx] = self.hashTable[curr_idx] # Move current record to empty record
						self.hashTable[curr_idx] = None # Delete current record
						empty_idx = curr_idx # Set empty position
					
					curr_idx = (curr_idx + 1)%self.capacity() # Increment current
				
				self.nRecords-=1
				return True
			
			curr_idx = (curr_idx + 1)%self.capacity() # Increment index
		
		return False
	
	#Search for record in hashtable
	def search(self, key):
		idx = __hashIndex__(key,self.capacity()) # Calculate HashIndex
		while self.hashTable[idx] is not None:
			if self.hashTable[idx].key == key:
				return self.hashTable[idx].value
			idx = (idx + 1) % self.capacity()
		
		return None
	
	# Return capacity of hashtable
	def capacity(self):
		return self.cap
	
	# Return number of records in hashtable
	def __len__(self):
		return self.nRecords