class Graph:

    def __init__(self, number_of_verts):
        self.vertices = number_of_verts # set the number of vertices
        self.adjList = [[] for _ in range(number_of_verts)] # initialize adjacency list for each vertex

    def add_vertex(self):
        self.vertices += 1 # increment the number of vertices
        self.adjList.append([]) # add an empty list to the adjacency list for the new vertex

    def add_edge(self, from_idx, to_idx, weight=1):
        if not (0 <= from_idx < self.vertices and 0 <= to_idx < self.vertices):
            return False  # invalid vertex indices

        if self.has_edge(from_idx, to_idx):
            return False  # edge already exists

        # add the edge to the adjacency list for the "from" vertex
        self.adjList[from_idx].append((to_idx, weight))
        return True

    def num_edges(self):
        count = 0
        for vertex_List in self.adjList:
            count += len(vertex_List) # add the number of edges for each vertex
        return count

    def num_verts(self):
        return self.vertices

    def has_edge(self, from_idx, to_idx):
        if from_idx < 0 or from_idx >= self.vertices:
            return False
        if to_idx < 0 or to_idx >= self.vertices:
            return False
        for vertexList in self.adjList[from_idx]:
            if vertexList[0] == to_idx:
                return True # check if there is an edge from "from_idx" to "to_idx"
        return False

    def edge_weight(self, from_idx, to_idx):
        if from_idx < 0 or from_idx >= self.vertices:
            return None
        if to_idx < 0 or to_idx >= self.vertices:
            return None
        for vertexList in self.adjList[from_idx]:
            if vertexList[0] == to_idx:
                return vertexList[1] # return the weight of the edge from "from_idx" to "to_idx"
        return None

    def get_connected(self, v):

        # Check if the input vertex index is valid
        if not (0 <= v < self.vertices):
            return None  # invalid vertex index

        # Create an empty list to store the connected vertices
        connectedVertices = []

        # Loop through the list of vertices adjacent to the input vertex
        for adjVertex in self.adjList[v]:
            # Add the adjacent vertex index and the weight of the connecting edge to the list
            connectedVertices.append((adjVertex[0], adjVertex[1]))

        # Return the list of connected vertices
        return connectedVertices


