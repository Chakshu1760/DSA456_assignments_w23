# A class for a min heap
class MinHeap:

    def __init__(self, arr=[]):
        
        self.heap = []
        # If input not empty, insert element into heap
        if arr:
            for val in arr:
                self.insert(val)

    def insert(self, element):
        
        self.heap.append(element)
        # Move the `element` up the tree as long as it is smaller than its parent
        self._bubble_up(len(self.heap) - 1)

    def _bubble_up(self, index):
        
        the_parent_idx = (index - 1) // 2
        # If the parent node exists and has a greater value than the current node, swap them and continue bubbling up
        if the_parent_idx >= 0 and self.heap[the_parent_idx] > self.heap[index]:
            self.heap[the_parent_idx], self.heap[index] = self.heap[index], self.heap[the_parent_idx]
            self._bubble_up(the_parent_idx)

    def get_min(self):
        if self.heap:
            return self.heap[0]
        else:
            return None
        

    def extract_min(self):
        if not self.heap:
            return None
        
        if len(self.heap) == 1:
            return self.heap.pop(0)
        # remove the root node,if heap has more than one node and then replace it with the last node, and bubble down the new root node
        min_val = self.heap[0]
        last_val = self.heap.pop()
        self.heap[0] = last_val
        self._bubble_down(0)
        return min_val

    def _bubble_down(self, index):
        leftchild_idx = 2 * index + 1
        
        rightchild_idx = 2 * index + 2
        
        min_idx = index

        # If the left child node exists and has a smaller value than the current node, set the minimum index to the left child's index
        if leftchild_idx < len(self.heap) and self.heap[leftchild_idx] < self.heap[min_idx]:
            min_idx = leftchild_idx

        # If the right child node exists and has a smaller value than the current node, set the minimum index to the right child's index
        if rightchild_idx < len(self.heap) and self.heap[rightchild_idx] < self.heap[min_idx]:
            min_idx = rightchild_idx

        # If the minimum index is not the current node's index, swap the nodes and continue bubbling down
        if min_idx != index:
            self.heap[index], self.heap[min_idx] = self.heap[min_idx], self.heap[index]
            self._bubble_down(min_idx)

    def is_empty(self):
        return len(self.heap) == 0

    def __len__(self):
        return len(self.heap)
