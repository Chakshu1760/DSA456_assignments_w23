import random
from a2d import Graph
from a3_partb import minimum_spanning_tree


def generate_maze(number_of_rows, number_of_columns):
   
   # Calculate total number of cells in the maze
    num_cells = number_of_rows * number_of_columns

    # Create a list of all walls
    walls = []

    for i in range(number_of_rows):
        for j in range(number_of_columns):
            cell = i * number_of_columns + j
            
            # Check if current cell is not in the last column
            if j < number_of_columns - 1:
            # Add a wall between the current cell and the cell to its right
                walls.append((cell, cell + 1))
               
            # Check if current cell is not in the last row
            if i < number_of_rows - 1:
            # Add a wall between the current cell and the cell below it
                walls.append((cell, cell + number_of_columns))
                
    # Create graph with random weights for each edge
    graph = Graph(num_cells)
    for wall in walls:
        weight = random.randint(1, 50)
        graph.add_edge(wall[0], wall[1], weight)
        graph.add_edge(wall[1], wall[0], weight)
    
    # Find minimum spanning tree
    mst = minimum_spanning_tree(graph)
    
    # Create list of walls to remove
    walls_to_remove = []
    for edge in mst:
        cell_1 = edge[0]
        cell_2 = edge[1]
        if cell_2 == cell_1 + 1:
            # Vertical wall
            walls_to_remove.append((cell_1, cell_1 + 1))
        elif cell_2 == cell_1 + number_of_columns:
            # Horizontal wall
            walls_to_remove.append((cell_1, cell_1 + number_of_columns))
    
    # rr Remove walls in walls_to_remove from original wall list
    maze_walls = [wall for wall in walls if wall not in walls_to_remove]
    
    return maze_walls
