class DisjointSet:
    def __init__(self,num):
        # Dictionary to store the parent of each element
        self.parent = {i: i for i in range(num)}
        # Dictionary to store the size of each set
        self.size = {i: i for i in range(num)}
        # Counter to store the number of sets
        self.num_sets = num

    def make_set(self, element):
        # If `element` already exists in the parent dictionary, return False
        if element in self.parent:
            return False
        # Set the parent of `element` to `element`
        self.parent[element] = element
        # Set the size of the set containing `element` to 1
        self.size[element] = 1
        # Increase the number of sets by 1
        self.num_sets += 1
        return True

    def get_set_size(self, element):
        # If `element` doesn't exist in the parent dictionary, return 0
        if element not in self.parent:
            return 0
        # Return the size of the set containing `element`
        return self.size[self.find_set(element)]

    def find_set(self, element):
        # If `element` doesn't exist in the parent dictionary, return None
        if element not in self.parent:
            return None
        # If the parent of `element` is `element`, return `element`
        if self.parent[element] == element:
            return element
        # Recursively find the root of the set containing `element`
        self.parent[element] = self.find_set(self.parent[element])
        return self.parent[element]

    def union_set(self, element1, element2):
        # If either `element1` or `element2` doesn't exist in the parent dictionary, return False
        if element1 not in self.parent or element2 not in self.parent:
            return False
        # Find the root of the set containing `element1`
        root1 = self.find_set(element1)
        # Find the root of the set containing `element2`
        root2 = self.find_set(element2)
        # If `root1` is the same as `root2`, return False
        if root1 == root2:
            return False
        # If the size of the set containing `root1` is greater than or equal to the size of the set containing `root2`, merge the set containing `root2` into the set containing `root1`
        if self.size[root1] >= self.size[root2]:
            self.parent[root2] = root1
            self.size[root1] += self.size[root2]
        # If the size of the set containing `root2` is greater than the size of the set containing `root1`, merge the set containing `root1` into the set containing `root2`
        else:
            self.parent[root1] = root2
            self.size[root2] += self.size[root1]
        # Decrease the number of sets by 1
        self.num_sets -= 1
        return True

    def get_num_sets(self):
        # Return the number of sets
        return self.num_sets
    
    def __len__(self):
        return len(self.parent)
