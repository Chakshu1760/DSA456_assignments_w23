from a1_partc import DisjointSet
from a2d import Graph
# add imports for your DisjointSet or MinHeap as you see fit


def minimum_spanning_tree(graph):
    # Sort the edges in increasing order of weight
    edges = []
    for i in range(graph.num_verts()):
        for j, w in graph.get_connected(i):
            edges.append((w, i, j))
    edges.sort()

    # Create a disjoint set to keep track of the connected components
    ds = DisjointSet(graph.num_verts())

    # Create an empty list to store the edges in the minimum spanning tree
    mst = []

    # Loop through the edges in increasing order of weight
    for w, u, v in edges:
        # If the two endpoints of the edge are not in the same connected component,
        # add the edge to the minimum spanning tree and merge the two connected components
        if ds.find_set(u) != ds.find_set(v):
            mst.append((u, v))
            ds.union_set(u, v)

    # Return the list of edges in the minimum spanning tree
    return mst
