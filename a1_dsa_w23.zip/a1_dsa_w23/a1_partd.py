
from maze import Maze

def find_path_recursive(the_maze, current_cell, end_cell, path=[]):

    # End cell is founded
    if current_cell == end_cell:
        return path + [end_cell]

    # Mark current cell    
    the_maze.mark_cell(current_cell)

    # Check if left path is is valid
    left_cell = the_maze.get_left(current_cell)
    if left_cell != -1 and not the_maze.get_is_marked(left_cell):
        left_path = find_path_recursive(the_maze, left_cell, end_cell, path + [current_cell])
        if left_path:
            return left_path

    # Check if right path is is valid
    right_cell = the_maze.get_right(current_cell)
    if right_cell != -1 and not the_maze.get_is_marked(right_cell):
        right_path = find_path_recursive(the_maze, right_cell, end_cell, path + [current_cell])
        if right_path:
            return right_path

    # Check if up path is is valid
    up_cell = the_maze.get_up(current_cell)
    if up_cell != -1 and not the_maze.get_is_marked(up_cell):
        up_path = find_path_recursive(the_maze, up_cell, end_cell, path + [current_cell])
        if up_path:
            return up_path

    # Check if down path is is valid
    down_cell = the_maze.get_down(current_cell)
    if down_cell != -1 and not the_maze.get_is_marked(down_cell):
        down_path = find_path_recursive(the_maze, down_cell, end_cell, path + [current_cell])
        if down_path:
            return down_path

    # Unmark cell if not ok
    the_maze.unmark_cell(current_cell)

    # Return empty path
    return []

# Find path entry point
def find_path(the_maze, start_cell, end_cell):
    return find_path_recursive(the_maze, start_cell, end_cell)
