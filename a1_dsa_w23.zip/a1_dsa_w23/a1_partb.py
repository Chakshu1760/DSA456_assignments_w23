class SetList:
    class Node:
        # Node constructor
        def __init__(self, data, sList : 'SetList', next = None, prev = None):
            self.data = data
            self.next = next
            self.prev = prev
            self.sList = sList
            
        # Return data stored in Node
        def get_data(self):
            return self.data
            
        # Return reference to next node in SetList
        def get_next(self):
            return self.next
            
        # Return reference to previous node in SetList
        def get_previous(self):
            return self.prev
            
        # Return reference to SetList
        def get_set(self):
            return self.sList
            
    # Set list Constructor
    def __init__(self):
        self.front = None
        self.back = None
        
    # Get front Node
    def get_front(self):
        return self.front
        
    # Get back Node
    def get_back(self):
        return self.back
        
    # Check existance of data in List and return corresponding Node
    def find_data(self, data):
        n = self.get_front()    # Initialize temporary node to first element
        
        while n:    # Iterate until end of
            if n.get_data() == data:
                return n
                
            n = n.get_next()
                
        return None
        
    # Get representative node
    def representative_node(self):
        if self.get_front():
            return self.get_front()
            
        return None
        
    # Return data of representative node
    def representative(self):
        rep = self.representative_node()
        
        if rep:
            return rep.get_data()
            
        return None
        
    # Add first value to SetList
    def make_set(self, data):
        if self.front: #Check if set list is not empty
            return None
            
        else:
            self.front = self.Node(data,self)
            self.back = self.front
            return self.front
            
    # Union between this list and the one passed by argument
    def union_set(self, other_set):

        n_mov_el = 0 # Number of elements that have been moved

        if other_set.get_front():   # Check if the set is not empty
        
            if len(self) != 0:
                self.back.next = other_set.get_front() # Set next Node of back of our list to the front node of other list
                
            while other_set.get_front() is not None: # Move elements until other_set is empty
                n_mov_el += 1
                other_set.get_front().prev = self.get_back()
                self.back =  other_set.get_front()
                self.back.sList = self
                other_set.front = other_set.front.get_next()
                
                if not other_set.get_front(): # Check if other_set has been emptied
                    other_set.back = None
                    
                if self.back and not self.front: # Set front element if list was empty before first operation
                    self.front = self.back

        return n_mov_el
                    
    # Return number of items in the list
    def __len__(self):
        n = 0
        node = self.get_front() 
        
        while node:
            node = node.get_next()
            n +=1
            
        return n

