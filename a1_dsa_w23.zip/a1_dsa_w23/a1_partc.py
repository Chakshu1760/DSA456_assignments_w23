from a1_partb import SetList

class DisjointSet:

    # Default constructor
    def __init__(self):
        self.elements = {} # Dictionary of elements
        self.nSets = 0 # Number of sets

    # Add element
    def make_set(self,element):
        
        if element in self.elements:# Check existance of element
            return False
            
        sList = SetList()   # Create SetList
        sList.make_set(element)

        self.elements[element] = sList.get_front()  # Add element and node to dictionary

        self.nSets += 1 # Increment number of sets in the DisjoinSet

        return True

    # Returns the representative of the set containining element
    def find_set(self, element):
        return self.elements[element].get_set().representative()

    # Return number of sets
    def get_num_sets(self):
        return self.nSets

    # Return number of elements
    def __len__(self):

        n = 0

        for key in self.elements.items():
            n+=1

        return n

    # Return size of the set containing element
    def get_set_size(self, element):

        if element in self.elements:# Check existance of element
                return self.elements[element].get_set().__len__() # Return number of element 

        return 0

    # Perform a union between sets that contains the elements
    def union_set(self, element1, element2):
        
        if element1 in self.elements and element2 in self.elements: # Check if both elements are present
        
            if self.elements[element1].get_set() == self.elements[element2].get_set(): # Check if they are in the same set 
                return False

            else:
                self.elements[element1].get_set().union_set(self.elements[element2].get_set()) # Perform union of sets
                self.nSets -= 1 # Decrement number of sets in the DisjoinSet
                return True
        
        return False
